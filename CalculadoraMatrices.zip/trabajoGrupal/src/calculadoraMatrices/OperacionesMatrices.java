package calculadoraMatrices;

import javax.swing.JOptionPane;

public class OperacionesMatrices {
	// Datos que me funcionaran a lo largo del programa
	private int[][] matrizA;
	private int[][] matrizB;
	private double[][] matrizResultadoDouble;

//Getters y Setters 
	public int[][] getMatrizA() {
		return matrizA;
	}

	public void setMatrizA(int[][] matrizA) {
		this.matrizA = matrizA;
	}

	public int[][] getMatrizB() {
		return matrizB;
	}

	public void setMatrizB(int[][] matrizB) {
		this.matrizB = matrizB;
	}

	public double[][] getMatrizResultadoDouble() {
		return matrizResultadoDouble;
	}

	public void setMatrizResultadoDouble(double [][] matrizResultadoDouble) {
		this.matrizResultadoDouble = matrizResultadoDouble;
	}

//OPERACIONES
//Imprimir matrices
	public String imprimirMatrices(int[][] matrizAImprimir) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < matrizAImprimir.length; i++) {
			for (int j = 0; j < matrizAImprimir[i].length; j++) {
				sb.append("["+matrizAImprimir[i][j] +"]"+" ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}
//Imprimir Matrices de tipo Double
	public String imprimirMatricesDouble(double[][] matrizAImprimir) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < matrizAImprimir.length; i++) {
			for (int j = 0; j < matrizAImprimir[i].length; j++) {
				sb.append("["+(Math.round(matrizAImprimir[i][j]*1000.0)/1000.0)+"]"+" ");
			}
			sb.append("\n");
		}
		return sb.toString();
		
	}
	
	
	
	
	
	
	
	
// Creacion Matriz
	
	public int[][] creacionMatriz(int f, int c) {
		int[][] matrizM = new int[f][c]; // -->Se creara una matriz momentanea
											// para pasar los valores y despues poder operar
		String[] filasMatriz = new String[f];
		String[] matrizStringSoloNumeros;

		for (int i = 0; i < f; i++) {
			filasMatriz[i] = JOptionPane.showInputDialog(
					"Ingrese la fila de su Matriz separando los datos con una coma (,) como se indica en el ejemplo [F1: 3,4,3] \n Fila"
							+ (i + 1));
//			if() {
//				JOptionPane.showMessageDialog(null, "Opcion Incorrecta");
//				OperacionesMatrices op2 = new OperacionesMatrices();
//				op2.creacionMatriz(f, c);
//				return matrizM;
			
			if(filasMatriz[i]!=null){
				   
				filasMatriz[i] = (String)filasMatriz[i];
				
				   if(!filasMatriz[i].trim().equals("")){
					   	matrizStringSoloNumeros = filasMatriz[i].split(",");
					   		for (int j = 0; j < c; j++) {
					   			matrizM[i][j] = Integer.parseInt(matrizStringSoloNumeros[j]);
					   		}      

				   }else{
						return matrizM;
			}}
		}
		return matrizM;
	}
	
	
	
	
	
	
	

//Suma Matrices
	public int[][] sumarMa(int[][] ma1, int[][] ma2) {
		int[][] sumaMatricesResult = new int[ma1.length][ma1[0].length];
		for (int i = 0; i < ma1.length; i++) {
			for (int j = 0; j < ma1[0].length; j++) {
				sumaMatricesResult[i][j] = ma1[i][j] + ma2[i][j];
			}
		}
		return sumaMatricesResult;
	}
	
	
	
	
	

//Resta Matrices
	public int[][] restaMa(int[][] ma1, int[][] ma2) {
		int[][] restaMatricesResult = new int[ma1.length][ma1[0].length];
		String opt = JOptionPane.showInputDialog(null, "Como desea operar? \n\t a---> A-B \n\t b---> B-A");
		
		//Aqui se gestiona el error 
		if(opt != null){   
			opt = (String)opt;
			
			   if(!opt.trim().equals("")){
				   
				char opcion = opt.charAt(0);
				
						switch (opcion) {
						case 'a': {
							for (int i = 0; i < ma1.length; i++) {
								for (int j = 0; j < ma1[0].length; j++) {
									restaMatricesResult[i][j] = ma1[i][j] - ma2[i][j];
								}
							}
							return restaMatricesResult;
						}
						case 'b': {
							for (int i = 0; i < ma1.length; i++) {
								for (int j = 0; j < ma1[0].length; j++) {
									restaMatricesResult[i][j] = ma2[i][j] - ma1[i][j];
								}
							}
							return restaMatricesResult;
						}
						}
			      JOptionPane.showMessageDialog(null, "Opcion no admitida, vuelva a intentarlo");
		return restaMatricesResult;


			   }else{
				   JOptionPane.showMessageDialog(null, "Opcion no admitida, vuelva a intentarlo");
					return restaMatricesResult;
			   }
	}
		JOptionPane.showMessageDialog(null, "Opcion no admitida, vuelva a intentarlo");
		return restaMatricesResult;
	}

	
	
	
	
//Multiplicacion de Matrices
	public int[][] multipliacionMa(int[][] ma1, int[][] ma2) {
		int[][] multipliMatricesResult = new int[ma1.length][ma2[0].length];
			for (int i = 0; i < ma1.length; i++) {
				for (int j = 0; j < ma2[0].length; j++) {
					for (int k = 0; k < ma1[0].length; k++) {
						multipliMatricesResult[i][j] += ma1[i][k] * ma2[k][j];
					}
				}
			}
			return multipliMatricesResult;
	}

	
	
	
	
	
//Matriz Transpuesta
	public int[][] transponerMatriz(int[][] m1) {

		int[][] matrizTranspuesta = new int[m1[0].length][m1.length];
		for (int i = 0; i < m1.length; i++) {
			for (int j = 0; j < m1[i].length; j++) {
				matrizTranspuesta[j][i] = m1[i][j];
			}
		}
		return matrizTranspuesta;
	}
	
	
	
	

//Obtener la determinante
	// Este metodo realiza las matrices de cofactores
	public void obtenerCofactor(int[][] matriz, int[][] temp, int p, int q, int n) {
		int i = 0, j = 0;
		for (int fila = 0; fila < n; fila++) {
			for (int columna = 0; columna < n; columna++) {
				if (fila != p && columna != q) {
					temp[i][j++] = matriz[fila][columna];
					if (j == n - 1) {
						j = 0;
						i++;
					}
				}
			}
		}
	}
	
	
	
	

// Este metodo opera la determinante
	public int determinanteMatriz(int[][] matriz, int n) {
		int determinante = 0;
		if (n == 1) {
			return matriz[0][0];
		}
		int[][] temp = new int[n][n];
		int multiplicador = 1;
		for (int f = 0; f < n; f++) {
			obtenerCofactor(matriz, temp, 0, f, n);
			determinante += multiplicador * matriz[0][f] * determinanteMatriz(temp, n - 1);
			multiplicador = -multiplicador;
		}
		return determinante;
	}

	
	
	
	
	
// Inversa
	public double[][] matrizInversa(int[][] matrizInt, int f, int c) {

		double[][] matriz = new double[f][c];

		for (int i = 0; i < matrizInt.length; i++) {
			for (int j = 0; j < matrizInt[i].length; j++) {
				matriz[i][j] = matrizInt[i][j];

			}
		}

		double det = 1 / determinante(matriz);
		double[][] nmatriz = matrizAdjunta(matriz);
		multiplicarMatriz(det, nmatriz);
		return nmatriz;
	}

	public double determinante(double[][] matriz) {
		double det;
		if (matriz.length == 2) {
			det = (matriz[0][0] * matriz[1][1]) - (matriz[1][0] * matriz[0][1]);
			return det;
		}
		double suma = 0;
		for (int i = 0; i < matriz.length; i++) {
			double[][] nm = new double[matriz.length - 1][matriz.length - 1];
			for (int j = 0; j < matriz.length; j++) {
				if (j != i) {
					for (int k = 1; k < matriz.length; k++) {
						int indice = -1;
						if (j < i)
							indice = j;
						else if (j > i)
							indice = j - 1;
						nm[indice][k - 1] = matriz[j][k];
					}
				}
			}
			if (i % 2 == 0)
				suma += matriz[i][0] * determinante(nm);
			else
				suma -= matriz[i][0] * determinante(nm);
		}
		return suma;
	}

	public double[][] matrizAdjunta(double[][] matriz) {
		if (matriz.length==2 && matriz[0].length==2)return matrizTranspuesta(matrizAdjunta2x2(matriz));
		return matrizTranspuesta(matrizCofactores(matriz));
	}
	
	public double [][] matrizAdjunta2x2(double [][] matriz){
		double [][] nm = new double [2][2];
		nm[0][0] = matriz[1][1];
		nm[0][1] = matriz[1][0]*(-1);
		nm[1][0] = matriz[0][1]*(-1);
		nm[1][1] = matriz[0][0];
		return nm;
	}
	
	public void multiplicarMatriz(double n, double[][] matriz) {
		for (int i = 0; i < matriz.length; i++)
			for (int j = 0; j < matriz.length; j++)
				matriz[i][j] *= n;
	}

	public double[][] matrizCofactores(double[][] matriz) {
		double[][] nm = new double[matriz.length][matriz.length];
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				double[][] det = new double[matriz.length - 1][matriz.length - 1];
				double detValor;
				for (int k = 0; k < matriz.length; k++) {
					if (k != i) {
						for (int l = 0; l < matriz.length; l++) {
							if (l != j) {
								int indice1 = k < i ? k : k - 1;
								int indice2 = l < j ? l : l - 1;
								det[indice1][indice2] = matriz[k][l];
							}
						}
					}
				}
				detValor = determinante(det);
				nm[i][j] = detValor * (double) Math.pow(-1, i + j + 2);
			}
		}
		return nm;
	}

	public double[][] matrizTranspuesta(double[][] matriz) {
		double[][] nuevam = new double[matriz[0].length][matriz.length];
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++)
				nuevam[i][j] = matriz[j][i];
		}
		return nuevam;
	}
}
