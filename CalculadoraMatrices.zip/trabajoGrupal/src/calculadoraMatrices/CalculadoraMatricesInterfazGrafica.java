package calculadoraMatrices;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
//import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.wb.swt.SWTResourceManager;

public class CalculadoraMatricesInterfazGrafica {
	private static Text numeroFilasA;
	private static Text numeroColumnasA;
	private static Text numeroFilasB;
	private static Text numeroColumnasB;
	
	private static int numFilasA;
	private static int numColumnasA;
	private static int numFilasB;
	private static int numColumnasB;
	
	
	public CalculadoraMatricesInterfazGrafica() {	
	}
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		//Para Trabajar con las operaciones de matrices
		OperacionesMatrices op = new OperacionesMatrices();
		
		Display display = new Display();
		Shell shlCalculadoraJava = new Shell();
		shlCalculadoraJava.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		shlCalculadoraJava.setSize(846, 540);
		shlCalculadoraJava.setText("Calculadora Java - Grupo ");
		shlCalculadoraJava.setLayout(null);
		shlCalculadoraJava.setLocation(300, 120);
		
		Label lblSaludo = new Label(shlCalculadoraJava, SWT.NONE);
		lblSaludo.setForeground(SWTResourceManager.getColor(0, 153, 153));
		lblSaludo.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lblSaludo.setFont(SWTResourceManager.getFont("Segoe UI", 18, SWT.BOLD | SWT.ITALIC));
		lblSaludo.setAlignment(SWT.CENTER);
		lblSaludo.setBounds(0, 0, 831, 34);
		lblSaludo.setText("Bienvenido a Calculadora de Matrices");
		
		Label lblOrden1 = new Label(shlCalculadoraJava, SWT.NONE);
		lblOrden1.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblOrden1.setForeground(SWTResourceManager.getColor(0, 102, 0));
		lblOrden1.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lblOrden1.setBounds(10, 33, 782, 21);
		lblOrden1.setText("Por favor, ingrese las dimensiones de las matrices antes de construirlas u operar.");
		
		Label txtDimensionMatrizA = new Label(shlCalculadoraJava, SWT.NONE);
		txtDimensionMatrizA.setForeground(SWTResourceManager.getColor(0, 102, 0));
		txtDimensionMatrizA.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		txtDimensionMatrizA.setBounds(10, 60, 284, 15);
		txtDimensionMatrizA.setText("Inserte la dimension de la matriz A [Filas x Columnas]:");
		
		Label txtDimensionMatrizB = new Label(shlCalculadoraJava, SWT.NONE);
		txtDimensionMatrizB.setForeground(SWTResourceManager.getColor(0, 102, 0));
		txtDimensionMatrizB.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		txtDimensionMatrizB.setText("Inserte la dimension de la matriz B [Filas x Columnas]:");
		txtDimensionMatrizB.setBounds(435, 60, 284, 15);
		
		Label lblOperaciones = new Label(shlCalculadoraJava, SWT.NONE);
		lblOperaciones.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lblOperaciones.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lblOperaciones.setForeground(SWTResourceManager.getColor(0, 102, 0));
		lblOperaciones.setBounds(24, 260, 125, 29);
		lblOperaciones.setText("Operaciones");
		
		Label lblResulConstMatrizA = new Label(shlCalculadoraJava, SWT.NONE);
		lblResulConstMatrizA.setFont(SWTResourceManager.getFont("Segoe UI", 20, SWT.NORMAL));
		lblResulConstMatrizA.setAlignment(SWT.CENTER);
		lblResulConstMatrizA.setBounds(78, 122, 232, 132);
		
		Label lblResulConstMatrizB = new Label(shlCalculadoraJava, SWT.NONE);
		lblResulConstMatrizB.setFont(SWTResourceManager.getFont("Segoe UI", 20, SWT.NORMAL));
		lblResulConstMatrizB.setAlignment(SWT.CENTER);
		lblResulConstMatrizB.setBounds(451, 122, 232, 132);
		
		Label lblRespuesta = new Label(shlCalculadoraJava, SWT.NONE);
		lblRespuesta.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_RED));
		lblRespuesta.setFont(SWTResourceManager.getFont("Segoe UI", 20, SWT.BOLD | SWT.ITALIC));
		lblRespuesta.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lblRespuesta.setBounds(78, 390, 161, 34);
		lblRespuesta.setText("RESPUESTA:");
		
		Label lblResultadoOperaciones = new Label(shlCalculadoraJava, SWT.NONE);
		lblResultadoOperaciones.setFont(SWTResourceManager.getFont("Segoe UI", 20, SWT.NORMAL));
		lblResultadoOperaciones.setAlignment(SWT.CENTER);
		lblResultadoOperaciones.setBounds(289, 350, 305, 140);
		
		Label lblx = new Label(shlCalculadoraJava, SWT.NONE);
		lblx.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lblx.setBounds(348, 60, 6, 15);
		lblx.setText("x");
		
		Label lblx2 = new Label(shlCalculadoraJava, SWT.NONE);
		lblx2.setText("x");
		lblx2.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lblx2.setBounds(772, 60, 6, 15);
		
		numeroFilasA = new Text(shlCalculadoraJava, SWT.BORDER);
		numeroFilasA.setBounds(300, 57, 42, 21);
		
		numeroColumnasA = new Text(shlCalculadoraJava, SWT.BORDER);
		numeroColumnasA.setBounds(358, 57, 42, 21);
		
		numeroFilasB = new Text(shlCalculadoraJava, SWT.BORDER);
		numeroFilasB.setBounds(725, 57, 42, 21);
		
		numeroColumnasB = new Text(shlCalculadoraJava, SWT.BORDER);
		numeroColumnasB.setBounds(779, 57, 42, 21);
		
		
		
			Button btnContruccionMatricesA = new Button(shlCalculadoraJava, SWT.NONE);
			btnContruccionMatricesA.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
			btnContruccionMatricesA.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnContruccionMatricesA.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				numFilasA = Integer.parseInt(numeroFilasA.getText());
				numColumnasA = Integer.parseInt(numeroColumnasA.getText());
				op.setMatrizA(op.creacionMatriz(numFilasA, numColumnasA));
				lblResulConstMatrizA.setText(op.imprimirMatrices(op.getMatrizA()));
			}
		});
		btnContruccionMatricesA.setBounds(118, 82, 135, 34);
		btnContruccionMatricesA.setText("Construir Matriz A");
		
		Button btnContruccionMatricesB = new Button(shlCalculadoraJava, SWT.NONE);
		btnContruccionMatricesB.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnContruccionMatricesB.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnContruccionMatricesB.setSize(135, 34);
		btnContruccionMatricesB.setLocation(505, 82);
		btnContruccionMatricesB.setText("Construir Matriz B");
		btnContruccionMatricesB.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				numFilasB = Integer.parseInt(numeroFilasB.getText());
				numColumnasB = Integer.parseInt(numeroColumnasB.getText());
				op.setMatrizB(op.creacionMatriz(numFilasB, numColumnasB));
				lblResulConstMatrizB.setText(op.imprimirMatrices(op.getMatrizB()));
				
				
			btnContruccionMatricesB.setText("Construir Matriz B");
			btnContruccionMatricesB.setBounds(500, 82, 135, 34);
			}
		});
		
		
		
		Button btnSumarMatrices = new Button(shlCalculadoraJava, SWT.NONE);
		btnSumarMatrices.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnSumarMatrices.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnSumarMatrices.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if((numFilasA==numFilasB)&&(numColumnasA==numColumnasB)) {
					lblResultadoOperaciones.setText(op.imprimirMatrices(op.sumarMa(op.getMatrizA(), op.getMatrizB())));
				} else JOptionPane.showMessageDialog(null, "No se puede realizar la suma. (Dimensiones distintas)");
				
			}
		});
		btnSumarMatrices.setBounds(50, 295, 75, 25);
		btnSumarMatrices.setText("SUMA");
		
		Button btnRestarMatrices = new Button(shlCalculadoraJava, SWT.NONE);
		btnRestarMatrices.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnRestarMatrices.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnRestarMatrices.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if((numFilasA==numFilasB)&&(numColumnasA==numColumnasB)) {
					lblResultadoOperaciones.setText(op.imprimirMatrices(op.restaMa(op.getMatrizA(), op.getMatrizB())));
				} else JOptionPane.showMessageDialog(null, "No se puede realizar la resta. (Dimensiones distintas)");
				
			}
		});
		btnRestarMatrices.setText("RESTA");
		btnRestarMatrices.setBounds(178, 295, 75, 25);
		
		Button btnMultiplicarMatrices = new Button(shlCalculadoraJava, SWT.NONE);
		btnMultiplicarMatrices.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnMultiplicarMatrices.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnMultiplicarMatrices.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (numColumnasA != numFilasB) {
					JOptionPane.showMessageDialog(null,
							"NO se puede realizar la operacion, ya que debe coincider el numero de columnas de la primera matriz "
									+ "con el numero de filas de la segunda. \n INTENTE CON CON OTRAS MATRICES");
				}else lblResultadoOperaciones.setText(op.imprimirMatrices(op.multipliacionMa(op.getMatrizA(), op.getMatrizB())));
			}
		});
		btnMultiplicarMatrices.setBounds(300, 295, 100, 25);
		btnMultiplicarMatrices.setText("MULTIPLICAR");
		
		Button btnTransponerMatrices = new Button(shlCalculadoraJava, SWT.NONE);
		btnTransponerMatrices.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnTransponerMatrices.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnTransponerMatrices.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				String opt = JOptionPane.showInputDialog(null, "Escoja la matriz que desea transponer \n\t a--> Matriz A \n\t b--> Matriz B");
				char opcion = opt.charAt(0);
					switch (opcion) {
						case 'a':{
							lblResultadoOperaciones.setText(op.imprimirMatrices(op.transponerMatriz(op.getMatrizA())));
						break;
						}
						case 'b':{
							lblResultadoOperaciones.setText(op.imprimirMatrices(op.transponerMatriz(op.getMatrizB())));
						break;
						}
						default:{
							JOptionPane.showMessageDialog(null, "Opcion no admitida, vuelva a intentarlo");
						}
					}
			}
		});
		btnTransponerMatrices.setBounds(435, 295, 107, 25);
		btnTransponerMatrices.setText("TRANSPUESTA");
		
		Button btnDeterminanteMatrices = new Button(shlCalculadoraJava, SWT.NONE);
		btnDeterminanteMatrices.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnDeterminanteMatrices.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnDeterminanteMatrices.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				String resultado;
				String opt = JOptionPane.showInputDialog(null, "Escoja la matriz que desea obtener la determinante \n\t a--> Matriz A \n\t b--> Matriz B");
				     char opcion = opt.charAt(0);
					switch (opcion) {
						case 'a':{
							if (numColumnasA!=numFilasA) {
								JOptionPane.showMessageDialog(null, "La matriz escogida no es cuadrada, intente con otras matrices");
								break;
							}
							resultado = Integer.toString(op.determinanteMatriz(op.getMatrizA(), numFilasA));
							lblResultadoOperaciones.setText(resultado);			
						break;
						}
						case 'b':{
							if (numColumnasB!=numFilasB) {
								JOptionPane.showMessageDialog(null, "La matriz escogida no es cuadrada, intente con otras matrices");
								break;
							}
							resultado = Integer.toString(op.determinanteMatriz(op.getMatrizB(), numFilasB));
							lblResultadoOperaciones.setText(resultado);	
						break;
						}
						default:{
							JOptionPane.showMessageDialog(null, "Opcion no admitida, vuelva a intentarlo");
						}
					}	
			}
		});
		
		
		
		btnDeterminanteMatrices.setBounds(571, 295, 112, 25);
		btnDeterminanteMatrices.setText("DETERMINANTE");
		
		Button btnInvertirMatrices = new Button(shlCalculadoraJava, SWT.NONE);
		btnInvertirMatrices.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.BOLD));
		btnInvertirMatrices.setForeground(SWTResourceManager.getColor(51, 153, 153));
		btnInvertirMatrices.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				String opt = JOptionPane.showInputDialog(null, "Escoja la matriz que desea obtener la inversa \n\t a--> Matriz A \n\t b--> Matriz B");
				char opcion = opt.charAt(0);
				if(opcion=='a') {
					if(numFilasA==numColumnasA) {
						if(op.determinanteMatriz(op.getMatrizA(), numFilasA)!=0) {
							lblResultadoOperaciones.setText(op.imprimirMatricesDouble(op.matrizInversa(op.getMatrizA(), numFilasA, numColumnasA)));
						}else JOptionPane.showMessageDialog(null, "Determinante de matriz es 0, no es posible calcular la inversa");
					}else JOptionPane.showMessageDialog(null, "La matriz A no es cuadrada, no es posible calcular la inversa");
				}else if (opcion=='b') {
					if(numFilasB==numColumnasB) {
						if(op.determinanteMatriz(op.getMatrizB(), numFilasB)!=0) {
							lblResultadoOperaciones.setText(op.imprimirMatricesDouble(op.matrizInversa(op.getMatrizB(), numFilasB, numColumnasB)));
						}else JOptionPane.showMessageDialog(null, "Determinante de matriz es 0, no es posible calcular la inversa");
					}else JOptionPane.showMessageDialog(null, "La matriz B no es cuadrada, no es posible calcular la inversa");
				}else JOptionPane.showMessageDialog(null, "Opcion no admitida, vuelva a intentarlo");
			}
		});
		
		
		
		btnInvertirMatrices.setBounds(703, 295, 75, 25);
		btnInvertirMatrices.setText("INVERSA");

		shlCalculadoraJava.open();
		shlCalculadoraJava.layout();
		while (!shlCalculadoraJava.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
}
